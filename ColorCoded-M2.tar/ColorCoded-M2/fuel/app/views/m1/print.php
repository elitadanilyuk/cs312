<!DOCTYPE html>
<html lang="en">
    <head>
    <?php echo Asset::css("M1.css");?>
    <link rel="icon" href="../../../m1/assets/img/company_small_icon.png">
    </head>

    <script>
        function printDiv(colorTable, alphTable, companyLogo, button) {
            var printContents = document.getElementById(companyLogo).innerHTML;
            printContents += document.getElementById(colorTable).innerHTML;
            //window.print(document.getElementById(alphTable).innerHTML);
            printContents += document.getElementById(alphTable).innerHTML;           

            w = window.open();
            w.document.write(printContents);
            w.print();
            w.close();
        }
    </script>

    <body>
        <main class="main">
            <header>
                <?php
                    $logo = "<img src='../../../m1/assets/img/company_logo.jpg' alt='color coded company logo' style='max-height:100px;'>";
                    echo "<div id='logo'>$logo</div>";
                ?>
                
            </header>
            <div class="contents">
               
                <?php

                    $curr_color;
	                $crtable = '';
                    if (isset($_POST['colors']) && isset($_POST['color_info'])){
                        $crtable .= '<table border="2">';

                        $temp = $_POST['color_info'];             
                        $color_info = (array) explode(',', $temp);

                        $color_choices = array();
                        $coordinates = array();
                        $selected_color = array_pop($color_info);
                        
                        for ($i = 0; $i < count($color_info); $i++) {
                            if (preg_match('/\d/', $color_info[$i])) {
                                $coordinates[$i] = $color_info[$i];
                            }
                            else {
                                $color_choices[$i] = $color_info[$i];
                            }
                        }                        
                        $coordinates = array_values($coordinates);

                        for ($i = 0; $i < $_POST['colors']; $i++) {
                            $curr_color = $color_choices[$i];
                            $crtable .= '<tr>';
                            for ($j = 0; $j < 2; $j++) {
                                if($j % 2 == 0){ 
                                    $crtable .= "<td style='height'='10px', 'width'='10px'>$curr_color</td>";
                                }
                                else{
                                    $crtable .= "<td width='80%'>";       

                                        if ($curr_color == $selected_color) {
                                            for ($k = 0; $k < count($coordinates); $k++) {
                                                $crtable .= $coordinates[$k];
                                                if ($k == count($coordinates) - 1) {
                                                    break;
                                                }                                                
                                                $crtable .= ", ";
                                            }
                                        }

                                    $crtable .= "</td>";
                                }
                                
                            }
                            $crtable .= '</tr>';
                        }
                        $crtable .= '</table>';
	                }
                ?>
                <br/>
                <br/>

                <?php
	               echo "<div id='colorTable'>$crtable</div>";
                ?>

                <?php
                    $numbers = range(1,26);
                    $alphabet = range('A', 'Z');
	                $num_table = '';
	                if (isset($_POST['num'])){ 
		                $num_table .= '<table id="table-2" class="table-2" border="2" style="height"="10px", "width"="10px">';
		                //for ($i = 0; $i < $_GET['num']+1; $i++) {
						for ($i = 0; $i < $_POST['num']+1; $i++) {
			                $num_table .= '<tr>';
			                //for ($j = 0; $j < $_GET['num']+1; $j++) {
							for ($j = 0; $j < $_POST['num']+1; $j++) {
                                if($i ==0 and $j == 0){
                                    $num_table .= '<td>&nbsp;</td>';
                                }
                                else if($i == 0){
                                    $num_table .= '<td>'.$alphabet[$j - 1].'</td>';
                                }
                                else if($j==0){
                                    $num_table .= '<td>'.$numbers[$i-1].'</td>';
                                }
                                else{
                                    $num_table .= '<td class="colorCell" id="cell';
                                    $num_table .= $numbers[$i-1]; #id is not zero-based
                                    $num_table .= $alphabet[$j-1];
                                    $num_table .= '">&nbsp;</td>';

                                }
                            }
                            $num_table .= '</tr>';
                        }
	                }
                ?>
                <br/>
                <br/>

                <?php
	               echo "<div id='alphTable'>$num_table</div>";
                ?>

                <script>
                    let color = document.querySelectorAll(".color_picker");
                    let color_map = new Map();
                    for (let i = 0; i < color.length; i++) {
                        color_map.set(i, 'blank');
                    }
                    for (let i = 0; i < color.length; i++) {
                        color[i].addEventListener("change", () => {
                            let can_set_new_color = true;
                            for (let j = 0; j < color_map.size; j++) {
                                if (color_map.get(j) == color[i].value) {
                                    can_set_new_color = false;
                                }
                            }
                            if (can_set_new_color) {
                                color_map.set(i, color[i].value);
                                document.querySelectorAll(".color_picker")[i].style.background = document.querySelectorAll(".drop-down")[i].value;
                            }
                            else {
                                color[i].value = color_map.get(i);
                                snackbar();
                            }
                        });
                    }

                    function snackbar() {
                        var x = document.getElementById("snackbar");
                        x.className = "show";
                        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
                    }
                </script>

                <div id="snackbar" class="no-print">All colors must be different.</div>

            </div>
            
        </main>
    </body>

    <footer>
       
        <!-- <div id="print-button">
            <form>
                <input type="button" onClick="printDiv('colorTable', 'alphTable')" value="Print">
            </form>
        <div>             -->
    </footer>

</html>
